import sys
import os
import json
import traceback

if __name__ == "__main__":
    try:
        req_path = os.environ.get("REQUEST_PATH")
        resp_path = os.environ.get("RESPONSE_PATH")
        
        if not req_path or not resp_path:
            print("Missing REQUEST_PATH or RESPONSE_PATH")
            sys.exit(1)

        with open(req_path, 'r') as f:
            req = json.load(f)
            
        action = req.get("action")
        
        if action == "run_plot":
            import plot
            image_path = req["image_path"]
            files_dir = req["files_dir"]
            max_temp = req["max_temp"]
            min_temp = req["min_temp"]
            
            # The python script outputs the 3 values
            derm_overlay_png, temps_json, colored_path = plot.run_plot(image_path, files_dir, max_temp, min_temp)
            
            with open(resp_path, 'w') as f:
                json.dump({
                    "status": "success",
                    "derm_overlay_png": derm_overlay_png,
                    "temps_json": temps_json,
                    "colored_path": colored_path
                }, f)
                
        elif action == "make_gif":
            import gif
            files_dir = req["files_dir"]
            out_name = req.get("out_name", "anim_imagenes.gif")
            gif_path = gif.make_gif(files_dir, out_name)
            
            with open(resp_path, 'w') as f:
                json.dump({
                    "status": "success",
                    "gif_path": gif_path
                }, f)
        else:
             with open(resp_path, 'w') as f:
                json.dump({"status": "error", "message": f"Unknown action {action}"}, f)

    except Exception as e:
        resp_path = os.environ.get("RESPONSE_PATH")
        if resp_path:
            with open(resp_path, 'w') as f:
                json.dump({
                    "status": "error",
                    "message": str(e),
                    "traceback": traceback.format_exc()
                }, f)
